#!/usr/bin/env sh
stop; sleep 2; sync; reboot
