# bootloop_simulator
WARNING: this is a practical joke, all this will do is bootloop your device
